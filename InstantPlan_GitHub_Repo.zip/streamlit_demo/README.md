# InstantPlan Streamlit Demo (Upgraded)

This is an upgraded Streamlit demo for the InstantPlan final project.
It demonstrates an end-to-end mock approval workflow:
- Upload plan (mock OCR)
- Mock AI analysis and rule checks
- Mock verification of BORAQS and EBK registration numbers
- Mock MPESA payment simulation
- QR generation (via Google Chart API) and PDF certificate download (simple)

Group members:
- Kelvin (AI/ML)
- Margaret Waithera Wambui (MERN)

SDG alignment: SDG 11 - Sustainable Cities and Communities

To run locally:
1. Install requirements: `pip install -r requirements.txt`
2. Run: `streamlit run app.py`
