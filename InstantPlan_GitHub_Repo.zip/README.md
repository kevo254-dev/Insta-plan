# InstantPlan
AI powered instant building plan approval system aligned with **SDG 11: Sustainable Cities and Communities**.

### Tech Stack
- FastAPI backend
- Streamlit demo app
- Mock AI model + OCR + QR generation
- MERN + AI collaboration project
- MPESA payment (simulated)
- Professional registry verification (mock BORAQS & EBK)

### Contributors
- **Kelvin** — AI/ML
- **Margaret Waithera Wambui** — MERN Stack

### How to Run
1. Navigate to the Streamlit demo folder:
   ```
   cd streamlit_demo
   pip install -r requirements.txt
   streamlit run app.py
   ```
2. Backend services are inside the `backend/` folder (if included).
3. Demo PDF included inside the project.
